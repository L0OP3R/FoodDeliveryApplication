package com.example.foodcatalogue.dto;

public class StudentTest {

	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub
	 * 
	 * Student student = new Student();
	 * 
	 * student.setName("vamsi"); student.setRollNo(2);
	 * student.setSubject("subject"); //student = null; student.setName("ami");
	 * System.out.println(student);
	 * 
	 * }
	 */

}
